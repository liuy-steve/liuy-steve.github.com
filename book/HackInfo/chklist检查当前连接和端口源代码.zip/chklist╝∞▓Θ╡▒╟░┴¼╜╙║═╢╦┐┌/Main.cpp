//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "Main.h"
#include "Ports.h"

//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TMainForm   *MainForm;
myPorts     *Ports;

//---------------------------------------------------------------------------
__fastcall TMainForm::TMainForm(TComponent *Owner) :
    TForm(Owner)
{
}

//----------------------------------------------------------------------------
void __fastcall TMainForm::FormCreate(TObject *Sender)
{
    Ports=new myPorts(ListView1);
}

//---------------------------------------------------------------------------
void __fastcall TMainForm::FormCloseQuery(TObject *Sender, bool &CanClose)
{
    delete Ports;
}

//---------------------------------------------------------------------------

void __fastcall TMainForm::ListView1Click(TObject *Sender)
{
    Ports->GetOpenPorts();
}
//---------------------------------------------------------------------------

