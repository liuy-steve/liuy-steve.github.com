//----------------------------------------------------------

//Ports.cpp
#include <vcl.h>
#include <Iphlpapi.h>
#include <Winsock.h>

#include "Ports.h"

//------------------------------------------------------------------

//���캯��������һ��TListView ��ָ�룬����������У�����һЩ�������ᱻ�ı䡣
myPorts::myPorts(TListView *T)
{
    pView=T;
}

//----------------------------------------------------------------------------
myPorts::~myPorts(void)
{
}

//----------------------------------------------------------------------------

//���к�������ȡ��ǰ�򿪵�����TCP�˿ڡ�
void myPorts::GetTCPPorts(void)
{
    MIB_TCPTABLE    *tcpTable=new MIB_TCPTABLE;
    DWORD           dwSize;
    dwSize=sizeof(MIB_TCPTABLE);

    GetTcpTable(tcpTable, &dwSize, true);
    delete  tcpTable;
    tcpTable=new MIB_TCPTABLE[dwSize/sizeof(MIB_TCPTABLE)];
    DWORD   getInfo=GetTcpTable(tcpTable, &dwSize, true);
    if(NO_ERROR == getInfo)
    {
        for(DWORD i=0; i < tcpTable->dwNumEntries; i++)
        {
            in_addr addr;
            addr.S_un.S_addr=tcpTable->table[i].dwRemoteAddr;

            char    *pcRAddr=inet_ntoa(addr);
            addr.S_un.S_addr=tcpTable->table[i].dwLocalAddr;
            char    *pcLAddr=inet_ntoa(addr);
            DWORD   LPort;
            DWORD   RPort;
            DWORD   State=tcpTable->table[i].dwState;

            //��ȡʵ�ʵĶ˿ںţ�DWORD���֣������ǵ��򣩣�
            RPort=(tcpTable->table[i].dwRemotePort & 0xff00)/256 + (tcpTable->table[i].dwRemotePort & 0xff)*256;
            LPort=(tcpTable->table[i].dwLocalPort & 0xff00)/256 + (tcpTable->table[i].dwLocalPort & 0xff)*256;

            TListItem   *ItemTemp;
            ItemTemp=pView->Items->Add();
            ItemTemp->ImageIndex=0;
            ItemTemp->Caption=pcLAddr;
            ItemTemp->SubItems->Add(LPort);
            ItemTemp->SubItems->Add("TCP");
            ItemTemp->SubItems->Add(pcRAddr);
            ItemTemp->SubItems->Add(RPort);
            ItemTemp->SubItems->Add(GetTCPState(State));
        }
    }
    else
    {
        LPVOID  lpMsgBuf;
        FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
                              NULL,
                              getInfo,
                              MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),    // Default language
                              (LPTSTR) & lpMsgBuf,
                              0,
                              NULL);
        MessageBox(NULL, (LPCTSTR) lpMsgBuf, "Error", MB_OK | MB_ICONINFORMATION);
        LocalFree(lpMsgBuf);

        //ShowMessage(AnsiString("Need ") + String(dwSize) + AnsiString(",give ") + String(sizeof(MIB_TCPTABLE)));
    }

    delete [] tcpTable;
}

//-----------------------------------------------------------------

//���к�������ȡ��ǰ�򿪵�����UDP�˿ڡ�
void myPorts::GetUDPPorts(void)
{
    MIB_UDPTABLE    *udpTable=new MIB_UDPTABLE;
    DWORD           dwSize;
    dwSize=sizeof(MIB_UDPTABLE);

    GetUdpTable(udpTable, &dwSize, true);
    delete  udpTable;
    udpTable=new MIB_UDPTABLE[dwSize/sizeof(MIB_UDPTABLE)];
    DWORD   getInfo=GetUdpTable(udpTable, &dwSize, true);
    if(NO_ERROR == getInfo)
    {
        for(DWORD i=0; i < udpTable->dwNumEntries; i++)
        {
            in_addr addr;
            addr.S_un.S_addr=udpTable->table[i].dwLocalAddr;
            char    *pcLAddr=inet_ntoa(addr);
            DWORD   LPort;

            //��ȡʵ�ʵĶ˿ںţ�DWORD���֣������ǵ��򣩣�
            LPort=(udpTable->table[i].dwLocalPort & 0xff00)/256 + (udpTable->table[i].dwLocalPort & 0xff)*256;

            TListItem   *ItemTemp;
            ItemTemp=pView->Items->Add();
            ItemTemp->ImageIndex=1;
            ItemTemp->Caption=pcLAddr;
            ItemTemp->SubItems->Add(LPort);
            ItemTemp->SubItems->Add("UDP");
            ItemTemp->SubItems->Add("");
            ItemTemp->SubItems->Add("");
            ItemTemp->SubItems->Add("��");
        }
    }
    else
    {
        LPVOID  lpMsgBuf;
        FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
                              NULL,
                              getInfo,
                              MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),    // Default language
                              (LPTSTR) & lpMsgBuf,
                              0,
                              NULL);
        MessageBox(NULL, (LPCTSTR) lpMsgBuf, "Error", MB_OK | MB_ICONINFORMATION);
        LocalFree(lpMsgBuf);

        //ShowMessage(AnsiString("Need ") + String(dwSize) + AnsiString(",give ") + String(sizeof(MIB_TCPTABLE)));
    }

    delete [] udpTable;
}

//------------------------------------------------------------------

//˽�к�������GetTCPPorts���ã�����TCP���ӵ�״̬���ţ�������������˼��
AnsiString myPorts::GetTCPState(DWORD dwState)
{
    switch(dwState)
    {
        case MIB_TCP_STATE_CLOSED:      return "�ѹر�";
        case MIB_TCP_STATE_LISTEN:      return "����";
        case MIB_TCP_STATE_SYN_SENT:    return "SNY ����";
        case MIB_TCP_STATE_SYN_RCVD:    return "SNY ����";
        case MIB_TCP_STATE_ESTAB:       return "��������";
        case MIB_TCP_STATE_FIN_WAIT1:   return "FIN �ȴ�";
        case MIB_TCP_STATE_FIN_WAIT2:   return "FIN �ȴ�";
        case MIB_TCP_STATE_CLOSE_WAIT:  return "�ȴ��ر�";
        case MIB_TCP_STATE_CLOSING:     return "���ڹر�";
        case MIB_TCP_STATE_LAST_ACK:    return "Last ACK";
        case MIB_TCP_STATE_TIME_WAIT:   return "Time Wait";
        case MIB_TCP_STATE_DELETE_TCB:  return "Delete TCP";
        default:                        return "";
    }
}

//---------------------------------------------------------------------------

//���к�����ˢ�����д򿪵Ķ˿ڵ���Ϣ
void myPorts::GetOpenPorts(void)
{
    pView->Items->Clear();
    GetTCPPorts();
    GetUDPPorts();
}
