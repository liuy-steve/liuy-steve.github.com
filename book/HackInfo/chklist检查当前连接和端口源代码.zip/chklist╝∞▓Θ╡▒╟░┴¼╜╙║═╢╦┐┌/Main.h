//---------------------------------------------------------------------------
#ifndef MainH
#define MainH

//---------------------------------------------------------------------------
#include <sysutils.hpp>
#include <windows.hpp>
#include <messages.hpp>
#include <sysutils.hpp>
#include <classes.hpp>
#include <graphics.hpp>
#include <controls.hpp>
#include <forms.hpp>
#include <dialogs.hpp>
#include <stdctrls.hpp>
#include <buttons.hpp>
#include <extctrls.hpp>
#include <menus.hpp>
#include <Classes.hpp>
#include <ComCtrls.hpp>
#include <Controls.hpp>
#include <ExtCtrls.hpp>
#include <StdCtrls.hpp>

//---------------------------------------------------------------------------
class TMainForm :
    public TForm
{
__published:
    TListView           *ListView1;
    TTimer              *Timer1;
    void __fastcall     FormCreate(TObject *Sender);
    void __fastcall     FormCloseQuery(TObject *Sender, bool &CanClose);
    void __fastcall ListView1Click(TObject *Sender);

/* */
private:    // private user declarations

/* */
public: // public user declarations
    virtual __fastcall  TMainForm(TComponent *Owner);
};

//---------------------------------------------------------------------------
extern TMainForm    *MainForm;

//---------------------------------------------------------------------------
#endif
