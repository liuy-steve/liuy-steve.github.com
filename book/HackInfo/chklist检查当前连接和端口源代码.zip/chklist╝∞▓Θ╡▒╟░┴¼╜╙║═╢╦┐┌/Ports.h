//-------------------------------------------------

//Ports.h
#ifndef PortsH
#define PortsH

//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <vcl/ComCtrls.hpp>
#include <vcl/ExtCtrls.hpp>
#include <vcl/Buttons.hpp>
#include <vcl/StdCtrls.hpp>

class   myPorts
{
/* */
private:
    TListView   *pView;
    void        GetTCPPorts(void);
    void        GetUDPPorts(void);
    AnsiString  GetTCPState(DWORD dwState);

/* */
public:
    void        GetOpenPorts(void);
    myPorts(TListView *T);
    ~myPorts(void);
};
#endif
